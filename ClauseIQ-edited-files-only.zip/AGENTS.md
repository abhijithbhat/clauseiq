<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## ClauseIQ architecture
- Domain logic lives in `src/lib/clauseiq/` (types, formatting, deadlines, demo cases, API client, letter export); UI in `src/components/clauseiq/`. Keeps the FastAPI contract and mock fallback in one place.
- The analysis backend is an external FastAPI service at `VITE_API_BASE_URL`; when `/health` fails, the app runs the 6-stage pipeline in simulation and shows bundled demo results, so the UI never hard-depends on the backend.
- Verdict and rule-outcome colours come only from `VERDICT_META` / `OUTCOME_META` mapped to semantic tokens in `src/styles.css`.
- Motion and interaction live in `src/styles.css` as shared utilities (`lift`, `press`, `animate-rise/pop/fill`) on one easing curve; entrance animations keep `animation-fill-mode: backwards` so a finished entrance never pins `:hover`/`:active` transforms, and the `prefers-reduced-motion` guard stays in place.
- Intake actions reuse the existing upload area and demo pipeline; verdict accent classes remain in `VERDICT_META` to keep presentation changes separate from claim analysis.
- Workspace corrections and letter placeholders live in browser-safe `workspace.ts`; offline edits invalidate legal findings and request human review rather than synthesizing verified conclusions.
- The workspace timeline distinguishes the 14-day grievance TAT from the 30-day no-response wait, uses recorded receipt dates, and labels repudiation-based filing dates as indicative because grievance triggers can differ.
