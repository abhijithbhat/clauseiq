export type Verdict = "LIKELY_WRONGFUL" | "CONTESTABLE" | "LIKELY_VALID" | "INSUFFICIENT_INFO";

export type RuleOutcome =
  | "CONTRADICTS_INSURER"
  | "SUPPORTS_INSURER"
  | "NEEDS_INFO"
  | "NOT_APPLICABLE";

export type DocumentKind = "POLICY" | "REJECTION_LETTER" | "DISCHARGE_SUMMARY";

export type EvidenceSource = DocumentKind | "REGULATION";

export interface RuleEvaluation {
  id: string;
  name: string;
  outcome: RuleOutcome;
  citation: string;
  finding: string;
  inputs?: Record<string, unknown>;
}

export type GrievanceReplyStatus = "UNKNOWN" | "AWAITING_REPLY" | "REPLY_RECEIVED" | "CONFIRMED_NO_RESPONSE";

export interface EditableFacts {
  policy_first_inception_date: string;
  admission_date: string;
  continuous_coverage_months: number;
  grievance_sent_date: string;
  grievance_received_date: string;
  grievance_reply_status: GrievanceReplyStatus;
  claim_amount: number;
}

export interface EvidenceItem {
  id: string;
  source: EvidenceSource;
  document_title: string;
  section: string;
  page: number;
  quote: string;
  match_score: number; // 0..1, character-level verbatim match
  relevance: string;
}

export interface AnalysisResult {
  case_id: string;
  claim_number: string;
  policy_number: string;
  insurer: string;
  insurer_grievance_email: string;
  product_name: string;
  policyholder: string;
  patient: string;
  hospital: string;
  diagnosis: string;
  treatment: string;
  claim_amount: number;
  settled_amount: number;
  disallowed_amount: number;
  sum_insured: number;
  first_inception_date: string; // ISO yyyy-mm-dd
  admission_date: string;
  repudiation_date: string;
  continuous_cover_months: number;
  rejection_reason: string;
  cited_clause: string;
  verdict: Verdict;
  confidence: number; // 0..100
  summary: string;
  appeal_grounds: string[];
  rules: RuleEvaluation[];
  evidence: EvidenceItem[];
  grievance_sent_date?: string;
  grievance_received_date?: string;
  grievance_reply_status?: GrievanceReplyStatus;
  needs_human_review?: boolean;
  field_sources?: Partial<Record<keyof EditableFacts, { page: number; document_title: string }>>;
}

export type StageStatus = "pending" | "running" | "done" | "failed";

export interface ProgressStep {
  name: string;
  status: StageStatus;
}

export interface ProgressResponse {
  status: "pending" | "running" | "completed" | "failed";
  current_step: number;
  steps: ProgressStep[];
}

export interface ManualFacts {
  first_inception_date?: string; // DD/MM/YYYY
  admission_date?: string;
}
